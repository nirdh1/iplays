-- iplays: run ONLY on the temporary restore project, AFTER the fingerprint comparison passed.
-- Keeps the operator's own account email (OPERATOR_EMAIL) so password sign-in can be tested;
-- every other address goes to the reserved .invalid domain; push targets and queued notifications are removed.
\set ON_ERROR_STOP on
-- guard: only a database carrying the restore-target marker (make_restore_marker.sh) may be changed
select to_regclass('iplays_restore_target.marker') is not null as is_target \gset
\if :is_target
\else
  \echo 'STOP: no restore-target marker: this is NOT the restore project'
  select 'STOP: not the restore project'::int;   -- deliberate error: psql exits non-zero, nothing changed
\endif
begin;
select current_database() as db \gset
update auth.users set email = 'restore+' || id || '@iplays-restore.invalid', phone = null
  where lower(email) is distinct from lower(:'operator_email');
delete from public.push_subscriptions;
delete from public.notification_outbox where sent_at is null;
select count(*) > 0 as left_real from auth.users
  where email not like '%@iplays-restore.invalid' and lower(email) is distinct from lower(:'operator_email') \gset
\if :left_real
  \echo 'STOP: real addresses remain'
  rollback;
  \quit
\endif
commit;
