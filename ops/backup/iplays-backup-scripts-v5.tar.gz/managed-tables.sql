-- iplays: exact row counts of every Supabase-managed auth/storage table (read-only; these tables are small).
\set ON_ERROR_STOP on
\pset format unaligned
\pset tuples_only on
\pset fieldsep ' | '
set default_transaction_read_only = on;
set statement_timeout = '30s';
set lock_timeout = '1s';
begin transaction read only;
select format('select %L, count(*) from %I.%I', n.nspname || '.' || c.relname, n.nspname, c.relname)
from pg_class c join pg_namespace n on n.oid = c.relnamespace
where c.relkind in ('r','p') and n.nspname in ('auth','storage')
order by n.nspname, c.relname
\gexec
rollback;
