#!/bin/bash
# Action 1: read-only checks on production with load and time limits.
# Usage: PROD_REF=<ref> DB_URL=postgresql://postgres.<ref>@<region>.pooler.supabase.com:5432/postgres ./preflight.sh
# (psql asks for the password; or export PGPASSWORD in the same terminal, never in a file)
source "$(dirname "$0")/common.sh"
: "${DB_URL:?set DB_URL (no password inside)}"; : "${PROD_REF:?set PROD_REF}"
need psql; need pg_dump; need pg_restore
check_url "$DB_URL" "$PROD_REF"
export PGOPTIONS='-c default_transaction_read_only=on -c statement_timeout=30s -c lock_timeout=1s'
export PGAPPNAME=iplays-backup-readonly
cd "$HERE"
static_check fingerprint.sql gaps.sql preflight-sizes.sql managed-tables.sql
readonly_probe "$DB_URL"
check_versions "$DB_URL"
check_is_production "$DB_URL"
psql_to preflight_sizes.txt "$DB_URL" preflight-sizes.sql; ok "catalog sizes -> preflight_sizes.txt"
big=$(psql_ro "$DB_URL" -At -c "select quote_ident(n.nspname)||'.'||quote_ident(c.relname) from pg_class c join pg_namespace n on n.oid=c.relnamespace where c.relkind='r' and n.nspname='public' order by pg_total_relation_size(c.oid) desc limit 1")
[ -n "$big" ] || die "could not find the largest table"
start=$SECONDS
psql_ro "$DB_URL" -At -c "select count(*), coalesce(sum(('x'||substr(md5(t::text),1,15))::bit(60)::bigint::numeric),0) from $big t" > single_table.txt
took=$((SECONDS - start))
[ $took -le 3 ] || die "hash of $big took ${took}s (> 3s): do not run the full fingerprint"
ok "hash of $big took ${took}s"
psql_to gaps.txt "$DB_URL" gaps.sql; ok "gaps -> gaps.txt"
psql_to managed_tables.txt "$DB_URL" managed-tables.sql; ok "managed table counts -> managed_tables.txt"
echo "PREFLIGHT PASSED"
