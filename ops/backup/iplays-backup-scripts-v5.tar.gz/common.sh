# iplays backup helpers (bash 3.2+). Sourced by preflight.sh, backup.sh, restore.sh.
set -euo pipefail          # a failing command anywhere in a pipeline stops the script
umask 077
die() { echo "STOP: $*" >&2; exit 1; }
ok()  { echo "OK: $*"; }
need() { command -v "$1" >/dev/null 2>&1 || die "missing tool: $1"; }
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PY="${PY:-python3}"

# Read-only session settings, sent as SQL at the start of EVERY production session.
# Supabase's pooler (Supavisor) does not pass PGOPTIONS (the "options" startup parameter) to Postgres,
# so PGOPTIONS alone is not enough there. PGOPTIONS is still exported as an extra layer for direct connections.
RO_SET=(-c "set default_transaction_read_only = on" -c "set statement_timeout = '30s'" -c "set lock_timeout = '1s'" -c "set idle_in_transaction_session_timeout = '60s'")
psql_ro() {  # psql_ro URL [psql options / -c / -f ...]: same session, read-only settings first
  local url=$1; shift
  psql -X -q -v ON_ERROR_STOP=1 "$url" "${RO_SET[@]}" "$@"
}

# The static check: no write command at the start of any statement line in our SQL files.
static_check() {
  local rc=0
  grep -nEi '^[[:space:]]*(insert|update|delete|truncate|alter|create|drop|grant|revoke|copy|merge|call|do|vacuum|reindex|cluster|lock|comment|security|refresh|import)\b' "$@" || rc=$?
  case $rc in
    0) die "write command found in SQL files (lines above)";;
    1) ok "static check: no write commands in $*";;
    *) die "static check could not read the files (grep exit $rc)";;
  esac
}

# Proof the session is read-only: a write must fail with the read-only error, nothing else.
readonly_probe() {
  local out rc=0
  # the SAME session setup the real queries use (psql_ro); the write must be refused with the read-only error
  out=$(psql_ro "$1" -c 'begin; create temp table ro_probe(); rollback;' 2>&1) || rc=$?
  [ $rc -eq 0 ] && die "session CAN write: read-only settings were not applied"
  case "$out" in
    *"read-only transaction"*) ok "read-only probe: write was refused";;
    *) die "probe failed for another reason (connection/password?): $out";;
  esac
}

# Run psql with output to a file; fail loudly on any error. No tee, so the exit code is psql's.
psql_to() {  # psql_to OUTFILE URL SQLFILE
  psql_ro "$2" -f "$3" > "$1" 2> "$1.err" || { cat "$1.err" >&2; die "psql failed on $3"; }
  [ -s "$1.err" ] && grep -qiE 'error|fatal' "$1.err" && { cat "$1.err" >&2; die "errors reported by $3"; }
  return 0
}

# ---- connection identity (added v4) ----
# The URL must name the expected project and must not carry a password.
# Supabase's pooler routes by the user name postgres.<ref>, so that name decides which project we reach.
# IPLAYS_LOCAL_TEST=1 (tests only): the database name stands in for the ref.
check_url() {  # check_url URL EXPECTED_REF OTHER_REF_THAT_MUST_NOT_APPEAR
  local url=$1 ref=$2 other=${3:-}
  [ -n "$ref" ] || die "project ref is empty"
  case "$url" in *://*:*@*) die "the URL contains a password: use PGPASSWORD or the prompt instead";; esac
  if [ -n "$other" ]; then case "$url" in *"$other"*) die "URL contains the other project's ref ($other)";; esac; fi
  if [ "${IPLAYS_LOCAL_TEST:-0}" = 1 ]; then
    case "$url" in *":///$ref?"*) ;; *) die "local test URL does not name database $ref";; esac
  else
    case "$url" in *"://postgres.$ref@"*) ;; *) die "URL user is not postgres.$ref";; esac
    case "$url" in *".pooler.supabase.com:5432/"*) ;; *) die "URL is not the Session pooler on port 5432";; esac
  fi
  ok "URL names project $ref, no password inside"
}

# Client tools must be at least as new as the server (pg_dump refuses older servers' features otherwise).
check_versions() {  # check_versions URL
  local srv cli
  srv=$(psql_ro "$1" -At -c "select current_setting('server_version_num')::int / 10000") || die "cannot read server version"
  for t in psql pg_dump pg_restore; do
    cli=$("$t" --version | sed -E 's/^[^0-9]*([0-9]+).*/\1/')
    [ "$cli" -ge "$srv" ] 2>/dev/null || die "$t major $cli is older than server major $srv"
  done
  ok "tools: $(pg_dump --version | sed 's/.*) //'), server major $srv"
}

# Production must look like production: our tables exist, and it is NOT marked as a restore target.
check_is_production() {  # check_is_production URL
  local r
  r=$(psql_ro "$1" -At -c "select (to_regclass('public.ifa_players') is not null)::text || ' ' || (select count(*) from pg_namespace where nspname = 'iplays_restore_target')") || die "identity query failed"
  [ "$r" = "true 0" ] || die "this database does not look like iplays production (got: $r)"
  ok "database has public.ifa_players and no restore-target marker"
}

# The restore project is identified POSITIVELY: a marker made by make_restore_marker.sh must be there,
# with the same random nonce as the local file and the same ref, and made within the last 48 hours.
check_is_restore_target() {  # check_is_restore_target URL REF IDFILE
  local url=$1 ref=$2 idf=$3 nonce r
  [ -f "$idf" ] || die "no $idf: run make_restore_marker.sh first"
  nonce=$(sed -n 's/^nonce=//p' "$idf"); [ ${#nonce} -eq 32 ] || die "bad nonce in $idf"
  grep -qx "ref=$ref" "$idf" || die "$idf was made for another project"
  r=$(psql -X -At -v ON_ERROR_STOP=1 "$url" -c "select count(*) from iplays_restore_target.marker where nonce = '$nonce' and restore_ref = '$ref' and created_at > now() - interval '48 hours'" 2>/dev/null) || die "no restore-target marker in this database: it is NOT the restore project"
  [ "$r" = 1 ] || die "restore-target marker does not match (wrong project, or older than 48h)"
  ok "positive identity: marker nonce and ref match ($ref)"
}

# Last guard: the operator types the restore ref by hand.
confirm_ref() {  # confirm_ref REF
  local typed
  printf 'Type the RESTORE project ref to continue: ' >&2
  IFS= read -r typed || die "no confirmation"
  [ "$typed" = "$1" ] || die "confirmation does not match"
  ok "operator confirmed $1"
}
