#!/usr/bin/env python3
"""iplays: exact comparison of two fingerprint outputs (offline). Python 3.8+.

Usage:
  python3 -I compare_fingerprints.py BEFORE AFTER            # restore check
  python3 -I compare_fingerprints.py --same-db BEFORE AFTER  # before/after on the same database

Each "== section" is compared as an ordered list of lines (fingerprint.sql orders every
query), so a missing, extra, changed or duplicated line fails. In restore mode two things
are excluded, and both are printed, never hidden: the server version line, and row-count
lines of Supabase-managed auth/storage tables that are deliberately not restored.
"""
import sys
from collections import Counter, OrderedDict

RESTORED_MANAGED = ('auth.users', 'auth.identities', 'storage.buckets', 'storage.objects')
REQUIRED_SECTIONS = ('== read_only', '== row count', '== policies', '== hash of our function')


def load(path):
    sections, current = OrderedDict(), None
    with open(path, encoding='utf-8') as fh:
        for raw in fh:
            line = raw.rstrip('\n')
            if line.startswith('== '):
                if line in sections:
                    raise SystemExit('ERROR: section twice in %s: %s' % (path, line))
                sections[line], current = [], line
            elif current is not None and line not in ('', 'BEGIN', 'ROLLBACK', 'SET'):
                sections[current].append(line)
    for req in REQUIRED_SECTIONS:
        if not any(s.startswith(req) for s in sections):
            raise SystemExit('ERROR: %s has no section starting with %r (incomplete run?)' % (path, req))
    ro = [v for k, v in sections.items() if k == '== read_only']
    if ro != [['on']]:
        raise SystemExit('ERROR: %s was not produced in a read-only session' % path)
    return sections


def managed_excluded(line):
    name = line.split(' | ')[0]
    return name.split('.')[0] in ('auth', 'storage') and name not in RESTORED_MANAGED


def main(argv):
    same_db = '--same-db' in argv
    args = [a for a in argv[1:] if a != '--same-db']
    if len(args) != 2:
        print(__doc__)
        return 2
    a, b = load(args[0]), load(args[1])
    failures = 0
    for name in sorted(set(a) | set(b), key=lambda s: (s not in a, list(a).index(s) if s in a else 0)):
        la, lb = a.get(name), b.get(name)
        if la is None or lb is None:
            print('FAIL section only in %s: %s' % ('AFTER' if la is None else 'BEFORE', name))
            failures += 1
            continue
        if not same_db and name == '== server':
            if la != lb:
                print('INFO server version differs: %s -> %s' % (la, lb))
            continue
        if not same_db and name.startswith('== row count'):
            for line in la:
                if managed_excluded(line):
                    print('INFO not restored (managed): ' + line)
            la = [l for l in la if not managed_excluded(l)]
            lb_skipped = [l for l in lb if managed_excluded(l)]
            lb = [l for l in lb if not managed_excluded(l)]
            for line in lb_skipped:
                print('INFO in restore target (managed, created by Supabase): ' + line)
        if la != lb:
            failures += 1
            ca, cb = Counter(la), Counter(lb)
            print('FAIL ' + name)
            for line in sorted((ca - cb).elements()):
                print('   only in BEFORE (or more times): ' + line)
            for line in sorted((cb - ca).elements()):
                print('   only in AFTER  (or more times): ' + line)
            if ca == cb:
                print('   same lines, different order')
    print('RESULT: ' + ('PASS' if failures == 0 else 'FAIL (%d sections)' % failures))
    return 0 if failures == 0 else 1


if __name__ == '__main__':
    sys.exit(main(sys.argv))
