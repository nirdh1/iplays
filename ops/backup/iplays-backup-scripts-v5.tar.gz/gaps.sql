-- iplays: read-only lists explaining the policy / function gaps vs the repo.
\set ON_ERROR_STOP on
\pset format unaligned
\pset tuples_only on
set default_transaction_read_only = on;
set statement_timeout = '30s';
set lock_timeout = '1s';
select current_setting('transaction_read_only') = 'on' as ro \gset
\if :ro
\else
  \echo 'ABORT: session is not read-only'
  \quit
\endif
\echo '== A. policies (schema.table.policy)'
select schemaname || '.' || tablename || '.' || policyname from pg_policies
where schemaname in ('public','storage') order by 1;
\echo '== B. functions in public: owner (ours / extension) + signature'
select coalesce('ext:' || e.extname, 'ours') || ' ' || p.proname || '(' || pg_get_function_identity_arguments(p.oid) || ')'
from pg_proc p
left join pg_depend d on d.objid = p.oid and d.classid = 'pg_proc'::regclass and d.deptype = 'e'
left join pg_extension e on e.oid = d.refobjid
where p.pronamespace = 'public'::regnamespace order by 1;
\echo '== C. triggers on auth / storage tables that are not Supabase internal'
select n.nspname || '.' || c.relname || ' ' || t.tgname
from pg_trigger t join pg_class c on c.oid = t.tgrelid join pg_namespace n on n.oid = c.relnamespace
where not t.tgisinternal and n.nspname in ('auth','storage') order by 1;
