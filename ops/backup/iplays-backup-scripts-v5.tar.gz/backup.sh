#!/bin/bash
# Action 3: one read-only pg_dump of public+auth+storage, bracketed by two fingerprints,
# then offline extraction and checks. Usage: PROD_REF=<ref> DB_URL=... ./backup.sh OUTDIR
source "$(dirname "$0")/common.sh"
: "${DB_URL:?set DB_URL}"; : "${PROD_REF:?set PROD_REF}"; OUT="${1:?output directory}"
need psql; need pg_dump; need pg_restore; need "$PY"
check_url "$DB_URL" "$PROD_REF"
T0=$SECONDS
export PGOPTIONS='-c default_transaction_read_only=on -c statement_timeout=30s -c lock_timeout=1s'
export PGAPPNAME=iplays-backup-readonly
mkdir -p "$OUT"; cp "$HERE"/{fingerprint.sql,check_dump.py,compare_fingerprints.py} "$OUT"/; cd "$OUT"
static_check fingerprint.sql
readonly_probe "$DB_URL"
check_versions "$DB_URL"
check_is_production "$DB_URL"
psql_to fingerprint_before.txt "$DB_URL" fingerprint.sql
pg_dump "$DB_URL" -Fc --lock-wait-timeout=5s -n public -n auth -n storage -f iplays.dump || die "pg_dump failed"
psql_to fingerprint_after.txt "$DB_URL" fingerprint.sql
"$PY" -I compare_fingerprints.py --same-db fingerprint_before.txt fingerprint_after.txt > same_db.txt || { cat same_db.txt; die "database changed during the backup: run again"; }
ok "no change during backup"
unset PGPASSWORD
# ---- offline from here: no connection to production
pg_restore -l iplays.dump > iplays.dump.toc
pg_restore -f schema_public.sql --schema-only -n public iplays.dump
pg_restore -f data_public.sql   --data-only   -n public iplays.dump
pg_restore -f data_auth.sql     --data-only   -n auth    -t users -t identities iplays.dump
pg_restore -f data_storage.sql  --data-only   -n storage -t buckets -t objects iplays.dump
grep -E 'POLICY storage objects medical_docs_' iplays.dump.toc > storage_policies.list || die "no medical_docs policies in the dump"
pg_restore -L storage_policies.list -f storage_policies.sql iplays.dump
# the extracted files really contain the four managed tables (content check, not exit code)
for t in 'auth.users' 'auth.identities' 'storage.buckets' 'storage.objects'; do
  f=data_${t%%.*}.sql
  grep -qE "^COPY ${t//./\\.} \(" "$f" || die "$t is missing from $f"
done
ok "auth.users, auth.identities, storage.buckets, storage.objects present in extracted files"
n_pol=$(grep -c '^CREATE POLICY' storage_policies.sql || true)
exp_pol=$(awk '/^== policies/{s=1;next} /^== /{s=0} s && $1=="storage"{print $3}' fingerprint_before.txt)
[ "$n_pol" = "${exp_pol:-0}" ] || die "storage policies: $n_pol in file, ${exp_pol:-0} in production"
ok "storage policies: $n_pol"
"$PY" -I check_dump.py fingerprint_before.txt data_public.sql data_auth.sql data_storage.sql > check_dump.txt || { cat check_dump.txt; die "backup files incomplete"; }
cat check_dump.txt
shasum -a 256 iplays.dump *.sql *.txt *.list *.toc *.py > SHA256SUMS 2>/dev/null || sha256sum iplays.dump *.sql *.txt *.list *.toc *.py > SHA256SUMS
# ---- report: sizes and integrity only. No row content, no emails, no secrets: safe to paste in chat.
{
  echo "iplays backup report $(date -u +%Y-%m-%dT%H:%MZ)"
  echo "project ref: $PROD_REF"
  echo "tools: $(pg_dump --version | sed 's/.*) //'), server major $(sed -n '/^== server/{n;p;}' fingerprint_before.txt | cut -c1-2)"
  echo "duration: $((SECONDS - T0))s"
  echo "-- files (bytes)"
  for f in iplays.dump schema_public.sql data_public.sql data_auth.sql data_storage.sql storage_policies.sql; do
    printf '%-22s %12s\n' "$f" "$(wc -c < "$f" | tr -d ' ')"
  done
  echo "-- integrity"
  echo "same snapshot before/after: $(tail -1 same_db.txt)"
  echo "check_dump: $(tail -1 check_dump.txt)  ($(grep -c '^OK' check_dump.txt) tables OK, $(grep -c '^FAIL' check_dump.txt || true) FAIL)"
  echo "storage policies: $n_pol"
  echo "dump sha256: $(grep ' iplays.dump$' SHA256SUMS | cut -c1-64)"
  echo "-- row counts per table (restored set, then managed tables not restored)"
  grep -E '^(OK|FAIL)' check_dump.txt | sed -E 's/^(OK  |FAIL) ([^:]+): fingerprint ([0-9]+).*/\2 \3/'
  grep '^INFO' check_dump.txt | sed -E 's/^INFO /not restored: /'
} > report.txt
cat report.txt
echo "BACKUP PASSED: $OUT"
