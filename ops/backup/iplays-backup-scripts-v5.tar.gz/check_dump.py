#!/usr/bin/env python3
"""iplays: offline check that the plain-SQL data files hold every row of every table.
Never connects to a database. Works on Python 3.8+.

Usage:
  python3 -I check_dump.py FINGERPRINT DATA_FILE [DATA_FILE ...]

FINGERPRINT is the output of fingerprint.sql taken from production (row count section).
Rules (exit code 1 on any failure):
  * every table of schema public, plus auth.users, auth.identities, storage.buckets,
    storage.objects ("restored set") must have exactly one COPY block, also when empty,
    and its row count must equal the fingerprint;
  * a COPY block that never ends (truncated file), a block that appears twice, or a block
    for a table that is not in the fingerprint is a failure;
  * every other auth/storage table (Supabase-managed, not restored) is listed with its
    row count, including zero, so nothing is skipped silently.
"""
import sys

RESTORED_MANAGED = ('auth.users', 'auth.identities', 'storage.buckets', 'storage.objects')


def die(msg):
    print('ERROR: ' + msg)
    sys.exit(2)


def read_fingerprint(path):
    counts, section, seen_section = {}, None, False
    with open(path, encoding='utf-8') as fh:
        for raw in fh:
            line = raw.rstrip('\n')
            if line.startswith('== '):
                section = line
                if section.startswith('== row count'):
                    seen_section = True
                continue
            if section and section.startswith('== row count') and line:
                parts = line.split(' | ')
                if len(parts) != 3 or not parts[1].isdigit():
                    die('unexpected line in fingerprint row section: %r' % line)
                if parts[0] in counts:
                    die('table listed twice in fingerprint: ' + parts[0])
                counts[parts[0]] = int(parts[1])
    if not seen_section or not counts:
        die('fingerprint has no row count section: ' + path)
    return counts


def parse_ident(s, i):
    """Parse one SQL identifier starting at s[i]; return (name, next_index)."""
    if i < len(s) and s[i] == '"':
        out, i = [], i + 1
        while i < len(s):
            if s[i] == '"':
                if i + 1 < len(s) and s[i + 1] == '"':
                    out.append('"')
                    i += 2
                    continue
                return ''.join(out), i + 1
            out.append(s[i])
            i += 1
        raise ValueError('unterminated quoted identifier')
    j = i
    while j < len(s) and (s[j].isalnum() or s[j] in '_$'):
        j += 1
    if j == i:
        raise ValueError('identifier expected at %d' % i)
    return s[i:j].lower(), j


def parse_copy_header(line):
    """'COPY schema.table (cols) FROM stdin;' -> 'schema.table' or None if not a COPY header."""
    if not line.startswith('COPY ') or not line.endswith(' FROM stdin;'):
        return None
    schema, i = parse_ident(line, 5)
    if line[i:i + 1] != '.':
        raise ValueError('schema-qualified name expected')
    table, i = parse_ident(line, i + 1)
    return schema + '.' + table


def read_copy_blocks(paths):
    counts = {}
    for path in paths:
        current, n, lineno = None, 0, 0
        with open(path, encoding='utf-8') as fh:
            for raw in fh:
                lineno += 1
                if current is None:
                    line = raw.rstrip('\n')
                    try:
                        name = parse_copy_header(line)
                    except ValueError as exc:
                        die('%s:%d bad COPY header (%s): %r' % (path, lineno, exc, line))
                    if name is not None:
                        if name in counts:
                            die('COPY block for %s appears twice (%s:%d)' % (name, path, lineno))
                        current, n = name, 0
                elif raw.rstrip('\n') == '\\.':
                    counts[current] = n
                    current = None
                else:
                    if not raw.endswith('\n'):
                        die('%s: last line has no newline inside COPY block for %s (truncated file)' % (path, current))
                    n += 1
        if current is not None:
            die('TRUNCATED: COPY block for %s in %s never ends' % (current, path))
    return counts


def main(argv):
    if len(argv) < 3:
        print(__doc__)
        return 2
    expected = read_fingerprint(argv[1])
    got = read_copy_blocks(argv[2:])
    restored = sorted(t for t in expected if t.startswith('public.')) + [t for t in RESTORED_MANAGED]
    failures = 0
    for t in restored:
        e = expected.get(t)
        g = got.get(t)
        if e is None:
            status, failures = 'FAIL', failures + 1
            note = 'not in fingerprint'
        elif g is None:
            status, failures = 'FAIL', failures + 1
            note = 'no COPY block in files'
        elif g != e:
            status, failures = 'FAIL', failures + 1
            note = 'row count differs'
        else:
            status, note = 'OK  ', ''
        print('%s %s: fingerprint %s, files %s %s' % (status, t, e, g, note))
    for t in sorted(got):
        if t not in restored:
            print('FAIL %s: COPY block in files but not part of the restored set' % t)
            failures += 1
    print('-- managed tables NOT restored (row counts from production):')
    for t in sorted(expected):
        if not t.startswith('public.') and t not in RESTORED_MANAGED:
            print('INFO %s: %d rows' % (t, expected[t]))
    print('RESULT: ' + ('PASS' if failures == 0 else 'FAIL (%d)' % failures))
    return 0 if failures == 0 else 1


if __name__ == '__main__':
    sys.exit(main(sys.argv))
