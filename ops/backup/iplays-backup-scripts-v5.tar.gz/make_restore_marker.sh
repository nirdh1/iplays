#!/bin/bash
# Before action 7: mark the NEW temporary project as the restore target.
# Usage: ./make_restore_marker.sh <restore project ref>
# Writes restore_target.id (local, mode 600) and prints SQL to paste in THAT project's SQL editor.
source "$(dirname "$0")/common.sh"
REF="${1:?restore project ref}"
[ "$REF" != "${PROD_REF:-}" ] || die "this is the production ref"
nonce=$(openssl rand -hex 16)
printf 'ref=%s\nnonce=%s\n' "$REF" "$nonce" > "$HERE/restore_target.id"
ok "wrote $HERE/restore_target.id"
cat <<SQL
-- paste in the SQL editor of project $REF ONLY (never in production)
create schema iplays_restore_target;
revoke all on schema iplays_restore_target from public, anon, authenticated;
create table iplays_restore_target.marker(nonce text primary key, restore_ref text not null, created_at timestamptz not null default now());
insert into iplays_restore_target.marker(nonce, restore_ref) values ('$nonce', '$REF');
SQL
