-- iplays fingerprint v2: read-only, low load. Same file on production and on the restored copy;
-- the two outputs must be identical (only the "server" line may differ).
-- Run: PGOPTIONS='-c default_transaction_read_only=on' psql -X -v ON_ERROR_STOP=1 "$DB_URL" -f fingerprint.sql > out.txt
\set ON_ERROR_STOP on
\pset format unaligned
\pset tuples_only on
\pset fieldsep ' | '
set default_transaction_read_only = on;
set statement_timeout = '30s';      -- no single query may run longer
set lock_timeout = '1s';            -- never wait behind a lock
set idle_in_transaction_session_timeout = '60s';
begin transaction isolation level repeatable read read only;   -- one consistent snapshot for the whole file
-- guard: stop at once unless the session is really read-only
select current_setting('transaction_read_only') = 'on' as ro \gset
\if :ro
\else
  \echo 'ABORT: session is not read-only'
  \quit
\endif
\echo '== read_only'
select current_setting('transaction_read_only');

\echo '== server'
select current_setting('server_version_num');

\echo '== extensions (name version schema)'
select extname || ' ' || extversion || ' ' || extnamespace::regnamespace from pg_extension order by 1;

\echo '== custom roles (not built-in, not Supabase-managed)'
select rolname from pg_roles
where rolname !~ '^pg_' and rolname not in ('postgres','anon','authenticated','service_role','authenticator',
  'supabase_admin','supabase_auth_admin','supabase_storage_admin','supabase_functions_admin','supabase_replication_admin',
  'supabase_read_only_user','supabase_realtime_admin','supabase_etl_admin','supabase_privileged_role','dashboard_user','pgbouncer','pgsodium_keyholder',
  'pgsodium_keyiduser','pgsodium_keymaker','cli_login_postgres')
order by 1;

\echo '== row count + order-free content hash per table (public, auth, storage)'
-- one sequential scan per table, constant memory: sum of 60-bit row hashes
select format(
  'select %L, count(*), coalesce(sum((''x''||substr(md5(t::text),1,15))::bit(60)::bigint::numeric),0) from %I.%I t',
  n.nspname || '.' || c.relname, n.nspname, c.relname)
from pg_class c join pg_namespace n on n.oid = c.relnamespace
where c.relkind in ('r','p') and n.nspname in ('public','auth','storage')
order by n.nspname, c.relname
\gexec

\echo '== RLS flags per table (public, storage)'
select n.nspname || '.' || c.relname, c.relrowsecurity, c.relforcerowsecurity
from pg_class c join pg_namespace n on n.oid = c.relnamespace
where c.relkind = 'r' and n.nspname in ('public','storage') order by 1;

\echo '== policies: count + hash of full definitions'
select schemaname, count(*), md5(string_agg(concat_ws('#', tablename, policyname, permissive, roles::text, cmd, qual, with_check), E'\n' order by tablename, policyname))
from pg_policies where schemaname in ('public','storage') group by 1 order by 1;

\echo '== functions in public: ours vs extensions'
select coalesce('ext:' || e.extname, 'ours'), count(*)
from pg_proc p
left join pg_depend d on d.objid = p.oid and d.classid = 'pg_proc'::regclass and d.deptype = 'e'
left join pg_extension e on e.oid = d.refobjid
where p.pronamespace = 'public'::regnamespace group by 1 order by 1;

\echo '== hash of our function definitions'
select count(*), md5(string_agg(pg_get_functiondef(p.oid), E'\n' order by p.proname, pg_get_function_identity_arguments(p.oid)))
from pg_proc p
where p.pronamespace = 'public'::regnamespace and p.prokind in ('f','p')
  and not exists (select 1 from pg_depend d where d.objid = p.oid and d.classid = 'pg_proc'::regclass and d.deptype = 'e');

\echo '== our triggers (public tables, and any we added on auth/storage tables)'
select n.nspname, count(*), md5(coalesce(string_agg(pg_get_triggerdef(t.oid), E'\n' order by c.relname, t.tgname), ''))
from pg_trigger t join pg_class c on c.oid = t.tgrelid join pg_namespace n on n.oid = c.relnamespace
where not t.tgisinternal and n.nspname in ('public','auth','storage')
group by 1 order by 1;

\echo '== table grants (anon, authenticated, service_role)'
select count(*), md5(coalesce(string_agg(concat_ws('#', table_name, grantee, privilege_type), E'\n' order by table_name, grantee, privilege_type), ''))
from information_schema.role_table_grants
where table_schema = 'public' and grantee in ('anon','authenticated','service_role');

\echo '== function execute grants'
select count(*), md5(coalesce(string_agg(concat_ws('#', routine_name, grantee), E'\n' order by routine_name, grantee, specific_name), ''))
from information_schema.routine_privileges
where routine_schema = 'public' and grantee in ('anon','authenticated','service_role');

\echo '== columns'
select count(*), md5(string_agg(concat_ws('#', table_name, column_name, data_type, is_nullable, column_default), E'\n' order by table_name, ordinal_position))
from information_schema.columns where table_schema = 'public';

\echo '== sequences (last value)'
select schemaname || '.' || sequencename, coalesce(last_value, 0) from pg_sequences where schemaname = 'public' order by 1;

rollback;
