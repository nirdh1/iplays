-- iplays preflight: catalog statistics only (no table is scanned). Read-only.
\set ON_ERROR_STOP on
set default_transaction_read_only = on;
set statement_timeout = '10s';
select n.nspname || '.' || c.relname as table_name, c.reltuples::bigint as est_rows,
       pg_size_pretty(pg_total_relation_size(c.oid)) as size
from pg_class c join pg_namespace n on n.oid = c.relnamespace
where c.relkind = 'r' and n.nspname in ('public','auth','storage')
order by pg_total_relation_size(c.oid) desc limit 15;
select pg_size_pretty(pg_database_size(current_database())) as db_size, current_setting('server_version') as server;
