-- Dummy "production" for local tests only. Fake names, fake users.
create extension if not exists pgcrypto;
create extension if not exists pg_trgm with schema public;
create schema auth; create schema storage;
create table auth.users(instance_id uuid default '00000000-0000-0000-0000-000000000000', id uuid primary key, aud text default 'authenticated',
  email text, phone text, encrypted_password text, email_confirmed_at timestamptz, is_sso_user boolean default false);
create table auth.identities(id uuid primary key default gen_random_uuid(), user_id uuid references auth.users(id), identity_data jsonb, provider text);
create table auth.sessions(id uuid primary key default gen_random_uuid(), user_id uuid);
create table auth.refresh_tokens(id bigserial primary key, token text);
create table auth.schema_migrations(version text primary key);
create table auth.audit_log_entries(id uuid primary key default gen_random_uuid(), payload json);
create table storage.buckets(id text primary key, name text, public boolean);
create table storage.objects(id uuid primary key default gen_random_uuid(), bucket_id text, name text);
create table storage.migrations(id int primary key, name text);
insert into auth.users(id,email,encrypted_password,email_confirmed_at) values
 ('11111111-1111-1111-1111-111111111111','operator@example.com', crypt('Pw-Operator-1', gen_salt('bf')), now()),
 ('22222222-2222-2222-2222-222222222222','parent2@example.com', crypt('Pw-Parent-2', gen_salt('bf')), now());
insert into auth.identities(user_id, identity_data, provider) select id, jsonb_build_object('email',email), 'email' from auth.users;
insert into auth.sessions(user_id) select id from auth.users;
insert into auth.refresh_tokens(token) values ('a'),('b'),('c');
insert into auth.schema_migrations values ('20240101'),('20240202');
insert into auth.audit_log_entries(payload) values ('{}');
insert into storage.buckets values ('medical-docs','medical-docs',false);
insert into storage.migrations values (0,'create-migrations-table');
create table public.profiles(id uuid primary key references auth.users(id), display_name text);
insert into public.profiles values ('11111111-1111-1111-1111-111111111111','מפעיל'),('22222222-2222-2222-2222-222222222222','הורה');
create table public.ifa_players(id serial primary key, full_name text, birth_year int);
insert into public.ifa_players(full_name, birth_year) select 'שחקן '||g||E' עם \\ ותו\tטאב', 2010+(g%8) from generate_series(1,45494) g;
insert into public.ifa_players(full_name, birth_year) values ('כפול', 2014), ('כפול', 2014);   -- deliberate duplicate rows
create table public."Weird Name"("Col A" int);  insert into public."Weird Name" values (1),(2);
create table public.empty_table(id int);
create table public.player_guardians(player_id int, user_id uuid references auth.users(id));
insert into public.player_guardians values (1,'11111111-1111-1111-1111-111111111111'),(2,'11111111-1111-1111-1111-111111111111'),(3,'22222222-2222-2222-2222-222222222222');
create table public.notification_outbox(id serial primary key, user_id uuid, body text, sent_at timestamptz);
create table public.push_subscriptions(id serial primary key, user_id uuid, endpoint text);
insert into public.push_subscriptions(user_id, endpoint) values ('22222222-2222-2222-2222-222222222222','https://push.example/abc');
create function public.notify_on_guardian() returns trigger language plpgsql as $$ begin insert into public.notification_outbox(user_id, body) values (new.user_id, 'new child'); return new; end $$;
create trigger guardian_notify after insert on public.player_guardians for each row execute function public.notify_on_guardian();
alter table public.player_guardians enable row level security;
create policy guardians_own on public.player_guardians for select to authenticated using (user_id = '11111111-1111-1111-1111-111111111111');
grant select on public.player_guardians to authenticated;
alter table storage.objects enable row level security;
create policy medical_docs_insert on storage.objects for insert to authenticated with check (bucket_id = 'medical-docs');
create policy medical_docs_select on storage.objects for select to authenticated using (bucket_id = 'medical-docs');
create policy medical_docs_delete on storage.objects for delete to authenticated using (bucket_id = 'medical-docs');
