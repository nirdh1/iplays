-- Simulates a NEW empty Supabase project: managed auth/storage tables already exist (with their own migration rows).
create extension if not exists pgcrypto;
create schema auth; create schema storage;
create table auth.users(instance_id uuid default '00000000-0000-0000-0000-000000000000', id uuid primary key, aud text default 'authenticated',
  email text, phone text, encrypted_password text, email_confirmed_at timestamptz, is_sso_user boolean default false);
create table auth.identities(id uuid primary key default gen_random_uuid(), user_id uuid references auth.users(id), identity_data jsonb, provider text);
create table auth.sessions(id uuid primary key default gen_random_uuid(), user_id uuid);
create table auth.refresh_tokens(id bigserial primary key, token text);
create table auth.schema_migrations(version text primary key);
create table auth.audit_log_entries(id uuid primary key default gen_random_uuid(), payload json);
create table storage.buckets(id text primary key, name text, public boolean);
create table storage.objects(id uuid primary key default gen_random_uuid(), bucket_id text, name text);
create table storage.migrations(id int primary key, name text);
insert into auth.schema_migrations values ('20240101'),('20240202'),('20250303');
insert into storage.migrations values (0,'create-migrations-table');
alter table storage.objects enable row level security;
