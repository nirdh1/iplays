#!/bin/bash
# iplays backup scripts: local tests on a throw-away Postgres with DUMMY data only.
# Never touches Supabase. Usage: PGHOST=/tmp PGPORT=55433 PGUSER=postgres [PY=python3] tests/run_tests.sh
set -uo pipefail
SRC="$(cd "$(dirname "$0")/.." && pwd)"
PY="${PY:-python3}"; export PY
W="$(mktemp -d)"
cp "$SRC"/*.sh "$SRC"/*.sql "$SRC"/*.py "$SRC"/tests/*.sql "$W"/
chmod +x "$W"/*.sh
cd "$W" || exit 2
H="${PGHOST:-/tmp}"; P="${PGPORT:-55433}"; U="${PGUSER:-postgres}"
PROD="postgresql:///prod_sim?host=$H&port=$P&user=$U"
TGT="postgresql:///restore_sim?host=$H&port=$P&user=$U"
RO='-c default_transaction_read_only=on -c statement_timeout=30s -c lock_timeout=1s'
PASS=0; FAIL=0
export IPLAYS_LOCAL_TEST=1 PROD_REF=prod_sim   # local test mode: database name stands in for the Supabase ref
OTH="postgresql:///other_sim?host=$H&port=$P&user=$U"
expect() {  # expect pass|fail "name" command...  (exit 126/127 = could not run = never a valid 'fail')
  local want=$1 name=$2 out rc; shift 2
  out=$("$@" 2>&1); rc=$?
  if { [ "$want" = pass ] && [ $rc -eq 0 ]; } || { [ "$want" = fail ] && [ $rc -ne 0 ] && [ $rc -lt 126 ]; }; then
    PASS=$((PASS+1)); printf 'PASS  %-62s (exit %d) %s\n' "$name" $rc "$(printf '%s' "$out" | grep -E 'STOP|ERROR|FAIL|RESULT' | tail -1 | cut -c1-90)"
  else
    FAIL=$((FAIL+1)); printf 'FAIL  %-62s (exit %d, wanted %s)\n' "$name" $rc "$want"; printf '%s\n' "$out" | tail -8 | sed 's/^/      /'
  fi
}
q() { psql -X -At -v ON_ERROR_STOP=1 "$1" -c "$2"; }
check_eq() { expect pass "$1 [$2 = $3]" test "$2" = "$3"; }

echo "== setup: python $("$PY" -V 2>&1), $(psql -V)"
for f in check_dump.py compare_fingerprints.py; do expect pass "py_compile $f" "$PY" -m py_compile "$f"; done
for f in common.sh preflight.sh backup.sh restore.sh make_restore_marker.sh; do expect pass "bash -n $f" bash -n "$f"; done
psql -X -q -d "postgresql:///postgres?host=$H&port=$P&user=$U" <<'SQL' >/dev/null
drop database if exists prod_sim; drop database if exists restore_sim; drop database if exists other_sim;
create database prod_sim; create database restore_sim; create database other_sim;
do $$ begin
  if not exists (select 1 from pg_roles where rolname='anon') then create role anon nologin; end if;
  if not exists (select 1 from pg_roles where rolname='authenticated') then create role authenticated nologin; end if;
  if not exists (select 1 from pg_roles where rolname='service_role') then create role service_role nologin; end if;
end $$;
SQL
psql -X -q -v ON_ERROR_STOP=1 "$PROD" -f seed_dummy.sql >/dev/null || { echo "seed failed"; exit 2; }
psql -X -q -v ON_ERROR_STOP=1 "$TGT" -f seed_target.sql >/dev/null || { echo "seed target failed"; exit 2; }
psql -X -q -v ON_ERROR_STOP=1 "$OTH" -f seed_target.sql >/dev/null || { echo "seed other failed"; exit 2; }
mkdir -p pooler
for t in psql pg_dump; do printf '#!/bin/bash\nunset PGOPTIONS   # like Supavisor: the options startup parameter never reaches Postgres\nexec %s "$@"\n' "$(command -v $t)" > pooler/$t; chmod +x pooler/$t; done
POOL="PATH=$W/pooler:$PATH"
R() { local conf=$1; shift; printf '%s\n' "$conf" | env "$@"; }   # R <typed confirmation> VAR=... ./restore.sh DIR

echo "== 0. connection identity and tool versions (added v4)"
CU() { IPLAYS_LOCAL_TEST=${LT:-1} bash -c 'source ./common.sh; check_url "$@"' x "$@"; }
SUPA='postgresql://postgres.abcdefghijklmnop@aws-0-eu-central-1.pooler.supabase.com:5432/postgres'
expect pass "URL check: local prod_sim URL" CU "$PROD" prod_sim
expect pass "URL check: real Supabase pooler form" env LT=0 bash -c 'IPLAYS_LOCAL_TEST=0 bash -c "source ./common.sh; check_url \"\$0\" abcdefghijklmnop" "$0"' "$SUPA"
expect fail "URL check: wrong ref" env IPLAYS_LOCAL_TEST=0 bash -c 'source ./common.sh; check_url "$0" zzzzzzzzzzzzzzzz' "$SUPA"
expect fail "URL check: password inside URL" env IPLAYS_LOCAL_TEST=0 bash -c 'source ./common.sh; check_url "$0" abcdefghijklmnop' 'postgresql://postgres.abcdefghijklmnop:secret@aws-0-eu-central-1.pooler.supabase.com:5432/postgres'
expect fail "URL check: transaction pooler port 6543" env IPLAYS_LOCAL_TEST=0 bash -c 'source ./common.sh; check_url "$0" abcdefghijklmnop' 'postgresql://postgres.abcdefghijklmnop@aws-0-eu-central-1.pooler.supabase.com:6543/postgres'
expect fail "URL check: other project's ref appears" CU "$PROD" prod_sim prod
expect pass "versions: client >= server" bash -c 'source ./common.sh; check_versions "$0"' "$PROD"
mkdir -p oldbin; printf '#!/bin/bash\necho "pg_dump (PostgreSQL) 12.1"\n' > oldbin/pg_dump; chmod +x oldbin/pg_dump
expect fail "versions: old pg_dump is stopped" env PATH="$W/oldbin:$PATH" bash -c 'source ./common.sh; check_versions "$0"' "$PROD"
expect pass "identity: prod_sim looks like production" bash -c 'source ./common.sh; check_is_production "$0"' "$PROD"
expect fail "identity: empty project is NOT production" bash -c 'source ./common.sh; check_is_production "$0"' "$TGT"
expect fail "preflight.sh with the wrong PROD_REF" env PROD_REF=restore_sim DB_URL="$PROD" ./preflight.sh
expect fail "preflight.sh pointed at a non-production db" env PROD_REF=restore_sim DB_URL="$TGT" ./preflight.sh

echo "== 1. read-only guards"
printf 'select 1;\n  DELETE from x;\n' > bad.sql
expect pass "static check: real SQL files are clean" bash -c 'source ./common.sh; static_check fingerprint.sql gaps.sql preflight-sizes.sql managed-tables.sql'
expect fail "static check: file with DELETE is stopped" bash -c 'source ./common.sh; static_check bad.sql'
expect fail "static check: missing file is stopped (grep exit 2)" bash -c 'source ./common.sh; static_check no_such_file.sql'
expect pass "probe: read-only session refuses the write" env PGOPTIONS="$RO" bash -c 'source ./common.sh; readonly_probe "$0"' "$PROD"
expect pass "probe: still read-only when PGOPTIONS is dropped (pooler)" env PGOPTIONS= bash -c 'source ./common.sh; readonly_probe "$0"' "$PROD"
expect fail "probe: session WITHOUT the read-only SET is stopped" env PGOPTIONS= bash -c 'source ./common.sh; RO_SET=(-c "select 1"); readonly_probe "$0"' "$PROD"
expect pass "psql_ro: default_transaction_read_only is on without PGOPTIONS" bash -c 'source ./common.sh; [ "$(PGOPTIONS= psql_ro "$0" -At -c "show default_transaction_read_only")" = on ]' "$PROD"
expect pass "psql_ro: statement_timeout 30s without PGOPTIONS" bash -c 'source ./common.sh; [ "$(PGOPTIONS= psql_ro "$0" -At -c "show statement_timeout")" = 30s ]' "$PROD"
expect fail "psql_ro: an INSERT is refused" bash -c 'source ./common.sh; PGOPTIONS= psql_ro "$0" -c "insert into public.empty_table values (9)"' "$PROD"
check_eq "  ... and nothing was written" "$(q "$PROD" "select count(*) from public.empty_table")" 0
expect fail "probe: wrong database (other error) is stopped" env PGOPTIONS="$RO" bash -c 'source ./common.sh; readonly_probe "$0"' "postgresql:///no_such_db?host=$H&port=$P&user=$U"
expect fail "fingerprint.sql aborts if session is not read-only" bash -c "sed 's/read only;   -- one/read write; -- one/; s/^set default_transaction_read_only = on;//' fingerprint.sql > fp_rw.sql && psql -X -v ON_ERROR_STOP=1 '$PROD' -f fp_rw.sql | grep -q ABORT && exit 1"

echo "== 2. preflight (action 1)"
expect pass "preflight.sh, PGOPTIONS dropped like the pooler" env "$POOL" DB_URL="$PROD" ./preflight.sh
expect pass "managed_tables.txt lists auth.sessions" grep -q '^auth.sessions | 2$' managed_tables.txt
expect pass "managed_tables.txt lists storage.objects with 0 rows" grep -q '^storage.objects | 0$' managed_tables.txt
expect fail "preflight.sh without read-only probe passing (wrong db)" env PROD_REF=no_such_db DB_URL="postgresql:///no_such_db?host=$H&port=$P&user=$U" ./preflight.sh

echo "== 3. backup (action 3)"
expect pass "backup.sh, PGOPTIONS dropped like the pooler" env "$POOL" DB_URL="$PROD" ./backup.sh "$W/bk"
LOG=/tmp/pgtest/log; n0=$(wc -l < "$LOG")
PGOPTIONS='-c log_statement=all' pg_dump "$PROD" -Fc -n public -f /dev/null
expect pass "pg_dump itself runs in a READ ONLY transaction (server log)" bash -c 'tail -n +$(($1+1)) "$0" | grep -q "REPEATABLE READ, READ ONLY"' "$LOG" "$n0"
for t in auth.users auth.identities storage.buckets storage.objects; do
  f="bk/data_${t%%.*}.sql"
  n=$(awk -v h="COPY $t (" 'index($0,h)==1{s=1;next} s&&$0=="\\."{print c+0;exit} s{c++}' "$f")
  e=$(q "$PROD" "select count(*) from $t")
  check_eq "content of $f: rows of $t" "$n" "$e"
done
expect pass "report.txt written" test -s bk/report.txt
expect pass "report.txt has no email address or password" bash -c '! grep -nE "@|password|PGPASSWORD" bk/report.txt'
expect pass "report.txt shows check_dump PASS" grep -q '^check_dump: RESULT: PASS' bk/report.txt
expect pass "report.txt lists file sizes" grep -qE '^data_public.sql +[0-9]+$' bk/report.txt
check_eq "storage_policies.sql has 3 CREATE POLICY" "$(grep -c '^CREATE POLICY' bk/storage_policies.sql)" 3
expect pass "check_dump output shows quoted table public.Weird Name OK" grep -q '^OK   public.Weird Name: fingerprint 2, files 2' bk/check_dump.txt
expect pass "check_dump output shows empty table OK" grep -q '^OK   public.empty_table: fingerprint 0, files 0' bk/check_dump.txt
expect pass "check_dump lists not-restored managed tables (INFO)" grep -q '^INFO auth.sessions: 2 rows' bk/check_dump.txt
expect pass "duplicate ifa rows counted (45496)" grep -q '^OK   public.ifa_players: fingerprint 45496, files 45496' bk/check_dump.txt
mkdir -p shim
printf '#!/bin/bash\nPGOPTIONS= psql -X -q "%s" -c "insert into public.empty_table values (1)"\nexec %s "$@"\n' "$PROD" "$(command -v pg_dump)" > shim/pg_dump; chmod +x shim/pg_dump
expect fail "backup.sh detects a write during pg_dump" env PATH="$W/shim:$PATH" DB_URL="$PROD" ./backup.sh "$W/bk_changed"
PGOPTIONS= q "$PROD" "delete from public.empty_table" >/dev/null
printf '#!/bin/bash\necho "pg_dump: error: simulated" >&2; exit 1\n' > shim/pg_dump
out=$(env PATH="$W/shim:$PATH" DB_URL="$PROD" ./backup.sh "$W/bk_fail" 2>&1); rc=$?
expect fail "backup.sh stops when pg_dump fails" test $rc -eq 0
expect fail "  ... and never prints BACKUP PASSED" bash -c 'grep -q "BACKUP PASSED" <<<"$0"' "$out"

echo "== 4. check_dump.py failure cases"
cd bk || exit 2
CD() { "$PY" -I check_dump.py "$@"; }
expect pass "complete files" CD fingerprint_before.txt data_public.sql data_auth.sql data_storage.sql
head -c 300000 data_public.sql > t_trunc.sql
expect fail "truncated data file" CD fingerprint_before.txt t_trunc.sql data_auth.sql data_storage.sql
awk 'index($0,"COPY public.ifa_players (")==1{print;getline;next}{print}' data_public.sql > t_minus1.sql
expect fail "one row missing in ifa_players" CD fingerprint_before.txt t_minus1.sql data_auth.sql data_storage.sql
awk 'index($0,"COPY public.empty_table (")==1{skip=1;next} skip&&$0=="\\."{skip=0;next} !skip' data_public.sql > t_noempty.sql
expect fail "COPY block of EMPTY table missing" CD fingerprint_before.txt t_noempty.sql data_auth.sql data_storage.sql
expect fail "auth file not given" CD fingerprint_before.txt data_public.sql data_storage.sql
expect fail "same file given twice (duplicate blocks)" CD fingerprint_before.txt data_public.sql data_public.sql data_auth.sql data_storage.sql
{ cat data_storage.sql; printf 'COPY auth.sessions (id, user_id) FROM stdin;\n\\.\n'; } > t_extra.sql
expect fail "unexpected table block (auth.sessions)" CD fingerprint_before.txt data_public.sql data_auth.sql t_extra.sql
{ cat data_storage.sql; printf 'COPY public."broken (id) FROM stdin;\n\\.\n'; } > t_bad.sql
expect fail "malformed COPY header" CD fingerprint_before.txt data_public.sql data_auth.sql t_bad.sql
: > t_empty_fp.txt
expect fail "empty fingerprint" CD t_empty_fp.txt data_public.sql data_auth.sql data_storage.sql
printf '%s' "$(cat data_auth.sql)" > t_nonl.sql   # strips the final newline only
expect pass "file without final newline after the last block is fine" CD fingerprint_before.txt data_public.sql t_nonl.sql data_storage.sql

echo "== 5. compare_fingerprints.py cases"
CF() { "$PY" -I compare_fingerprints.py "$@"; }
expect pass "identical (same-db)" CF --same-db fingerprint_before.txt fingerprint_after.txt
awk '{print} /^public.profiles \|/{print}' fingerprint_before.txt > t_dup.txt
expect fail "duplicated line" CF --same-db fingerprint_before.txt t_dup.txt
sed 's/^public.Weird Name | 2 |/public.Weird Name | 3 |/' fingerprint_before.txt > t_cnt.txt
expect fail "changed row count" CF --same-db fingerprint_before.txt t_cnt.txt
awk '/^public.empty_table \|/{held=$0;next} {print} held&&/^public.ifa_players \|/{print held;held=""}' fingerprint_before.txt > t_ord.txt
out=$(CF --same-db fingerprint_before.txt t_ord.txt); rc=$?
expect fail "same lines, different order" test $rc -eq 0
expect pass "  ... reported as 'different order'" grep -q 'different order' <<<"$out"
head -n 20 fingerprint_before.txt > t_part.txt
expect fail "partial (interrupted) fingerprint" CF --same-db fingerprint_before.txt t_part.txt
awk 'p{print "off";p=0;next} /^== read_only/{p=1} {print}' fingerprint_before.txt > t_rw.txt
expect fail "fingerprint not taken read-only" CF --same-db fingerprint_before.txt t_rw.txt
cd "$W" || exit 2

echo "== 6a. positive identification of the restore project (added v4)"
RS="RESTORE_REF=restore_sim"
expect fail "no restore_target.id yet: refused" R restore_sim RESTORE_URL="$TGT" $RS ./restore.sh "$W/bk"
./make_restore_marker.sh other_sim > other_marker.out 2>&1 && mv restore_target.id other.id
grep -v '^OK:' other_marker.out | sed "s/now()/now() - interval '3 days'/" > other_marker.sql
psql -X -q -v ON_ERROR_STOP=1 "$OTH" -f other_marker.sql >/dev/null
expect fail "make_restore_marker refuses the production ref" ./make_restore_marker.sh prod_sim
./make_restore_marker.sh restore_sim > marker.out 2>&1
expect pass "marker id file is private (mode 600)" bash -c '[ "$(stat -c %a restore_target.id)" = 600 ]'
expect fail "marker not yet in the target db: refused" R restore_sim RESTORE_URL="$TGT" $RS ./restore.sh "$W/bk"
grep -v '^OK:' marker.out | psql -X -q -v ON_ERROR_STOP=1 "$TGT" >/dev/null
expect fail "RESTORE_URL = production: refused" R restore_sim RESTORE_URL="$PROD" $RS ./restore.sh "$W/bk"
expect fail "RESTORE_REF = PROD_REF: refused" R prod_sim RESTORE_URL="$PROD" RESTORE_REF=prod_sim ./restore.sh "$W/bk"
expect fail "other db, id file of restore_sim: refused" R other_sim RESTORE_URL="$OTH" RESTORE_REF=other_sim ./restore.sh "$W/bk"
expect fail "other db with its own but 3-day-old marker: refused" R other_sim RESTORE_URL="$OTH" RESTORE_REF=other_sim IDFILE="$W/other.id" ./restore.sh "$W/bk"
sed 's/^nonce=.*/nonce=00000000000000000000000000000000/' restore_target.id > wrong.id
expect fail "nonce does not match the marker: refused" R restore_sim RESTORE_URL="$TGT" $RS IDFILE="$W/wrong.id" ./restore.sh "$W/bk"
expect fail "operator types the wrong ref: refused" R restore_simX RESTORE_URL="$TGT" $RS ./restore.sh "$W/bk"
check_eq "  ... nothing was loaded by the refused runs" "$(q "$TGT" "select count(*) from pg_tables where schemaname='public'")" 0
expect fail "isolation script on production (no marker): refused" psql -X -v ON_ERROR_STOP=1 -v operator_email=operator@example.com "$PROD" -f post_restore_isolation.sql
check_eq "  ... production dummy untouched" "$(q "$PROD" "select count(*) from public.push_subscriptions")+$(q "$PROD" "select count(*) from auth.users where email like '%.invalid'")" "1+0"

echo "== 6. restore (action 7) into a simulated new project"
cp -R bk bk_tamper; sed -i '0,/^1\t/s//1\tX/' bk_tamper/data_public.sql
expect fail "checksum mismatch is stopped" R restore_sim RESTORE_URL="$TGT" $RS ./restore.sh "$W/bk_tamper"
cp -R bk bk_bad
awk 'index($0,"COPY public.ifa_players (")==1{print;getline;sub(/\t20[0-9][0-9]$/,"\tnot_a_year");print;next}{print}' bk/data_public.sql > bk_bad/data_public.sql
(cd bk_bad && rm -f SHA256SUMS && sha256sum iplays.dump *.sql *.txt *.list *.toc *.py > SHA256SUMS)
out=$(R restore_sim RESTORE_URL="$TGT" $RS ./restore.sh "$W/bk_bad" 2>&1); rc=$?
expect fail "bad value in data: restore fails" test $rc -eq 0
check_eq "  ... and the target is still empty (rolled back)" "$(q "$TGT" "select count(*) from pg_tables where schemaname='public'")+$(q "$TGT" "select count(*) from auth.users")" "0+0"
expect pass "restore.sh into the empty target" R restore_sim RESTORE_URL="$TGT" $RS ./restore.sh "$W/bk"
expect pass "v6: dump has a supabase_admin default-privilege line" grep -q '^ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin ' "$W/bk/schema_public.sql"
expect pass "v6: loaded copy leaves it out" bash -c '! grep -q "^ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin " "$0"' "$W/bk/schema_public.restore.sql"
expect pass "v6: loaded copy keeps postgres default privileges" grep -q '^ALTER DEFAULT PRIVILEGES FOR ROLE postgres ' "$W/bk/schema_public.restore.sql"
expect pass "  ... compare shows managed tables as INFO, not hidden" grep -q '^INFO not restored (managed): auth.sessions' bk/compare.txt
check_eq "auth user ids identical" "$(q "$TGT" "select string_agg(id::text,',' order by id) from auth.users")" "$(q "$PROD" "select string_agg(id::text,',' order by id) from auth.users")"
check_eq "guardian permissions identical" "$(q "$TGT" "select md5(string_agg(t::text,',' order by t::text)) from public.player_guardians t")" "$(q "$PROD" "select md5(string_agg(t::text,',' order by t::text)) from public.player_guardians t")"
check_eq "no trigger fired during load (outbox rows)" "$(q "$TGT" "select count(*) from public.notification_outbox")" "$(q "$PROD" "select count(*) from public.notification_outbox")"
expect fail "second restore refused: target not empty" R restore_sim RESTORE_URL="$TGT" $RS ./restore.sh "$W/bk"

echo "== 7. login after isolation (GoTrue password-grant lookup, same SQL rules)"
login() { q "$TGT" "select count(*) from auth.users where lower(email)=lower('$1') and aud='authenticated' and email_confirmed_at is not null and not is_sso_user and encrypted_password = crypt('$2', encrypted_password)"; }
check_eq "operator login before isolation" "$(login operator@example.com Pw-Operator-1)" 1
expect pass "post_restore_isolation.sql" psql -X -v ON_ERROR_STOP=1 -v operator_email=operator@example.com "$TGT" -f post_restore_isolation.sql
check_eq "operator login after isolation (email kept)" "$(login operator@example.com Pw-Operator-1)" 1
check_eq "parent's real address no longer exists" "$(login parent2@example.com Pw-Parent-2)" 0
check_eq ".invalid address still finds the user (no domain check)" "$(login restore+22222222-2222-2222-2222-222222222222@iplays-restore.invalid Pw-Parent-2)" 1
check_eq "no real address left except operator" "$(q "$TGT" "select count(*) from auth.users where email not like '%@iplays-restore.invalid' and email <> 'operator@example.com'")" 0
check_eq "push subscriptions removed in the copy" "$(q "$TGT" "select count(*) from public.push_subscriptions")" 0
check_eq "production dummy untouched (push subscriptions)" "$(q "$PROD" "select count(*) from public.push_subscriptions")" 1
expect fail "isolation without operator_email variable stops" psql -X -v ON_ERROR_STOP=1 "$TGT" -f post_restore_isolation.sql

echo "== 8. pipelines and tee"
expect pass "demo: without pipefail, 'false | tee' looks like success" bash -c 'false | tee /dev/null; echo reached'
expect fail "with set -euo pipefail the script stops at 'false | tee'" bash -c 'set -euo pipefail; false | tee /dev/null; echo reached'
printf 'select 1/0;\n' > div0.sql
expect fail "psql_to stops on an SQL error" bash -c 'source ./common.sh; psql_to o.txt "$0" div0.sql; echo SHOULD-NOT-PRINT' "$PROD"
expect pass "no script uses tee" bash -c '! grep -n "| *tee" common.sh preflight.sh backup.sh restore.sh'

echo
echo "TOTAL: $PASS passed, $FAIL failed (python: $("$PY" -V 2>&1))"
[ "${KEEP:-0}" = 1 ] && echo "kept $W" || rm -rf "${W:?}"
[ $FAIL -eq 0 ]
